package com.cg.mp.exception;

public class InvalidNumberException  extends RuntimeException{
	public InvalidNumberException(String msg)
	{
		super(msg);
	}

}
