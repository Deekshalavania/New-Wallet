package com.cg.mp.exception;

public class InvalidBalanceException extends RuntimeException{
public InvalidBalanceException(String msg)
{
	super(msg);
}
}
