package com.cg.mp.bean;
import java.math.BigDecimal;

public class Wallet {
	
	//private int id;
	private BigDecimal balance;
	
	// Getter Setter Method

	/*public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}*/
	public BigDecimal getBalance() {
		return this.balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	
	//Parameterized Constructor

	public Wallet( BigDecimal balance) {
		super();
		//this.id = id;
		this.balance = balance;
	}
	
	// Default Constructor
	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//toString Method
	
	@Override
	public String toString() {
		return "Wallet [ balance=" + balance + "]";
	}
	
}
