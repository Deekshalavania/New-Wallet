package com.cg.mp.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.exception.InvalidBalanceException;
import com.cg.mp.exception.InvalidNameException;
import com.cg.mp.exception.InvalidNumberException;
import com.cg.mp.repository.WalletRepositoryImplements;

public class WalletServiceImplements implements IWalletService {
	Customer c=new Customer();
	WalletRepositoryImplements repo;
	
	public WalletServiceImplements(Map<String,Customer> hm) {
	 
	repo=new WalletRepositoryImplements(hm);
	}

	@Override
	public Customer createAccount(String custName, String phoneNum, BigDecimal balance)
	{
		if(InvalidName(custName)&&Invalidnumber(phoneNum)&& InvalidBalance(balance))
		   if(repo.findByPhone(phoneNum)!=null)
			   throw new InvalidNameException("User with"+phoneNum+"already exist");
		repo.save(c);
		return c;
	}
	
	
    @Override
	public Customer showBalance(String phoneNum) 
	{
	  if(Invalidnumber(phoneNum))
		   repo.findByPhone(phoneNum);
	  else
		  throw new InvalidNumberException("User does not exist with this number");
	  return c;
		  
	}
	
	public boolean InvalidName(String name) throws InvalidNameException
	{
		if(name==null || name.length()<1)
			throw new InvalidNameException ("Customer name should not be null and it should be greater than two words");
	   return true;
	}
	
	public boolean Invalidnumber(String number) throws InvalidNumberException
	{
		if((number.length())!=10 )
			throw new InvalidNameException("Number should be of length 10 only");
		return true;
	}
	public boolean InvalidBalance(BigDecimal balance) throws InvalidBalanceException
	{
		if(balance==null)
			throw new InvalidBalanceException("BLanace can be greater than zero");
		return true;	
	}

}
