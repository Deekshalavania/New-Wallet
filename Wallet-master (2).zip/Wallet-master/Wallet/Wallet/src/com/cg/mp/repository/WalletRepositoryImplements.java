package com.cg.mp.repository;
import java.util.HashMap;

import java.util.Map;

import com.cg.mp.bean.Customer;

public class WalletRepositoryImplements implements IWalletRepository{

	Map<String,Customer> hm=new HashMap<>();
	
	public WalletRepositoryImplements(Map<String,Customer> hm)
	{
		super();
		this.hm=hm;
	}

	Customer c=new Customer();
	@Override
	public boolean save(Customer c) {
		if(hm.containsKey(c.getPhoneNum()))
		{
			hm.replace(c.getPhoneNum(),c);
		}
		else 
		{
			hm.put(c.getPhoneNum(),c);
			
		}
		return true;
	}

	@Override
	public Customer findByPhone(String phoneNum) {
		// TODO Auto-generated method stub
    
		
			c=hm.get(phoneNum);
		
		
		return c;
	
			
}
	
}
