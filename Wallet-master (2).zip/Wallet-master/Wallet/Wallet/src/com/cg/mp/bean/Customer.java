package com.cg.mp.bean;

public class Customer {

	private String custName;
	private String phoneNum;
	private Wallet wallet;
	
	// Getter and Setter Method
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	public Wallet getWallet() {
		return this.wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	
	// Parameterized Constructor
	
	public Customer(String custName, String phoneNum, Wallet wallet) {
		super();
		this.custName = custName;
		this.phoneNum = phoneNum;
		this.wallet = wallet;
	}
	
	// Default constructor
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	// toString Method

	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", phoneNum=" + phoneNum + "]";
	}
}
