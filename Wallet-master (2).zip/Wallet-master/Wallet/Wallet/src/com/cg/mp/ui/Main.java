package com.cg.mp.ui;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.mp.bean.Customer;
import com.cg.mp.exception.InvalidBalanceException;
import com.cg.mp.exception.InvalidNameException;
import com.cg.mp.exception.InvalidNumberException;
import com.cg.mp.service.WalletServiceImplements;

public class Main 
{
		//public static void main(String[] args) {
		String name;
		String phoneNum;
		BigDecimal balance;

        WalletServiceImplements wallserv;
        
      Map<String,Customer> hm=new HashMap<>();
      
     public  Main()
      {
    	  System.out.println("Welcome");
    	  wallserv=new WalletServiceImplements(hm);
      }
	public void Options() {
		int choice;
		Scanner scanner=new Scanner(System.in);
		System.out.println("1.Create Account");
		System.out.println("2.Find By Id");
		//System.out.println("3.Exit");
		System.out.println("Enter Choice");
		choice=scanner.nextInt();
		switch(choice)
		{
		case 1:System.out.println("Enter details       ");
		       name=scanner.next();
		       phoneNum=scanner.next();
		       balance=scanner.nextBigDecimal();
		       try {
		    	   
			        Customer cus =wallserv.createAccount(name, phoneNum, balance);
			        System.out.println("account created");
		           }
		       catch(InvalidBalanceException|InvalidNameException|InvalidNumberException a)
		       {
		    	   System.out.println(a.getMessage());
		       }
		       break;
		
		case 2: System.out.println("Enter mobile number through you want to find details");
		        phoneNum=scanner.next();
		        try {
		        	Customer cus=wallserv.showBalance(phoneNum);
		        	System.out.println(balance);
		            }
		       catch(InvalidNumberException a)
		           {
		    	    System.out.println(a.getMessage());
		           }
		break;
		
		case 3:System.out.println("Thanks for using wallet");
			   System.exit(0);
		       break;
		       
		default:System.out.println("Wrong Choice");
				break;
	}
	}


	public static void main(String[] args)	{
		
		Main main=new Main();
		while(true)
			main.Options();
}  
	}
	
	