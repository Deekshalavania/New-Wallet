package com.cg.mp.repository;

import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;

public interface IWalletRepository {

	boolean save(Customer c);
	Customer findByPhone(String phoneNum);
}
